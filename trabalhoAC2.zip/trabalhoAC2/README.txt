versão do python usada: Python 3.9.13

lista com versões das bibliotecas usadas:


librosa                   0.9.2
matplotlib                3.5.2           
numpy                     1.25.2
pandas                    1.4.4
scikit-learn              1.2.2
seaborn                   0.11.2
scipy                     1.9.1
soundata                  0.1.2
soundfile                 0.12.1
tensorflow                2.15.0

Para compilar o codigo basta executar todas as celulas presentes no notebook.